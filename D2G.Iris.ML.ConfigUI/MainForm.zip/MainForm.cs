﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Windows.Forms;
using D2G.Iris.ML.ConfigUI.Controls;
using D2G.Iris.ML.ConfigUI.Services;
using D2G.Iris.ML.ConfigUI.Utilities;
using D2G.Iris.ML.Core.Enums;
using D2G.Iris.ML.Core.Models;
using D2G.Iris.ML.Configuration;
using D2G.Iris.ML.Data;
using System.Text;

namespace D2G.Iris.ML.ConfigUI
{
    public partial class MainForm : Form
    {
        private readonly ConfigurationService _configService;
        private ModelConfig _currentConfig;
        private string _currentFilePath;

        // UI Controls
        private GeneralSettingsControl _generalSettingsControl;
        private DatabaseSettingsControl _databaseSettingsControl;
        private InputFieldsControl _inputFieldsControl;
        private TrainingParametersControl _trainingParametersControl;
        private Button btnLaunchTraining;
        private TabPage tabLogs;
        private RichTextBox txtConsoleOutput;
        private TextWriter _originalConsoleOut;

        public MainForm()
        {
            // Call the designer-generated InitializeComponent method
            InitializeComponent();

            _configService = new ConfigurationService();
            InitializeConfigurationControls();
            AddTrainingButton();
            AddConsoleTab();
            SetupTabLayout();
            InitializeMenuItems();

            // Add the configuration info menu item
            AddConfigInfoMenuItem();

            // Add handler to restore console output when form closes
            this.FormClosing += (sender, e) =>
            {
                ConsoleUtilities.RestoreConsoleOutput(_originalConsoleOut);
            };

            // Try to load the existing configuration file on startup
            LoadExistingConfigOnStartup();
        }

        private void LoadExistingConfigOnStartup()
        {
            try
            {
                // Define the primary configuration path - this will be our "single source of truth"
                string primaryConfigPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "modelconfig.json");

                // Log the path we're checking
                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    $"Loading configuration from: {primaryConfigPath}", LogLevel.Info);

                if (File.Exists(primaryConfigPath))
                {
                    try
                    {
                        // Load the configuration from the primary path
                        _currentConfig = _configService.LoadConfiguration(primaryConfigPath);
                        _currentFilePath = primaryConfigPath; // Important: Always use the same path
                        UpdateFormTitle();
                        UpdateUIFromConfig();

                        ConsoleUtilities.LogMessage(txtConsoleOutput,
                            $"Successfully loaded configuration", LogLevel.Success);
                        return;
                    }
                    catch (Exception loadEx)
                    {
                        // Log errors but don't switch to a different file
                        ConsoleUtilities.LogMessage(txtConsoleOutput,
                            $"Error loading configuration: {loadEx.Message}", LogLevel.Error);

                        // Notify the user
                        MessageBox.Show(
                            $"Error loading configuration: {loadEx.Message}\n\nCreating a new configuration.",
                            "Configuration Error",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    ConsoleUtilities.LogMessage(txtConsoleOutput,
                        $"Configuration file not found", LogLevel.Warning);
                }

                // If we get here, create a new configuration and save it to the primary path
                CreateNewConfiguration();

                // Immediately save the new configuration to the primary path
                _configService.SaveConfiguration(_currentConfig, primaryConfigPath);
                _currentFilePath = primaryConfigPath;
                UpdateFormTitle();

                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    $"Created and saved new configuration to: {primaryConfigPath}", LogLevel.Info);
            }
            catch (Exception ex)
            {
                // Handle any unexpected errors
                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    $"Unexpected error: {ex.Message}", LogLevel.Error);

                // Create a new configuration but don't try to save it
                CreateNewConfiguration();
                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    "Created a new configuration in memory (not saved)", LogLevel.Warning);
            }
        }

        private void InitializeConfigurationControls()
        {
            _generalSettingsControl = new GeneralSettingsControl();
            _databaseSettingsControl = new DatabaseSettingsControl();
            _inputFieldsControl = new InputFieldsControl();
            _trainingParametersControl = new TrainingParametersControl();
        }

        private void AddTrainingButton()
        {
            // Create a new button
            btnLaunchTraining = new Button
            {
                Text = "Launch Training",
                BackColor = Color.Green,
                ForeColor = Color.White,
                Font = new Font(Font.FontFamily, 10, FontStyle.Bold),
                Width = 150,
                Height = 40,
                Dock = DockStyle.Bottom,
                Margin = new Padding(10),
                Cursor = Cursors.Hand
            };

            // Add click event handler
            btnLaunchTraining.Click += BtnLaunchTraining_Click;

            // Add to form
            this.Controls.Add(btnLaunchTraining);
        }

        private void AddConsoleTab()
        {
            // Create a new tab for console output
            tabLogs = new TabPage
            {
                Text = "Training Logs",
                UseVisualStyleBackColor = true
            };

            // Create a rich text box to show console output
            txtConsoleOutput = new RichTextBox
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BackColor = Color.Black,
                ForeColor = Color.LightGreen,
                Font = new Font("Consolas", 10),
                Multiline = true,
                ScrollBars = RichTextBoxScrollBars.Both,
                WordWrap = false
            };

            // Add to tab and tab control
            tabLogs.Controls.Add(txtConsoleOutput);
            tabControl.TabPages.Add(tabLogs);

            // Redirect console output to our text box
            _originalConsoleOut = ConsoleUtilities.RedirectConsoleOutput(txtConsoleOutput);

            // Add a welcome message
            ConsoleUtilities.LogMessage(txtConsoleOutput,
                "Welcome to Iris ML Configuration Tool", LogLevel.Info);
            ConsoleUtilities.LogMessage(txtConsoleOutput,
                "Use the tabs to configure your model settings and click 'Launch Training' to start training", LogLevel.Info);
        }

        private void AddConfigInfoMenuItem()
        {
            var configInfoMenuItem = new ToolStripMenuItem("Configuration Info");
            configInfoMenuItem.Click += (s, e) =>
            {
                string primaryPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "modelconfig.json");

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("CONFIGURATION INFORMATION");
                sb.AppendLine("=========================");
                sb.AppendLine($"Primary Config Path: {primaryPath}");
                sb.AppendLine($"Current Config Path: {_currentFilePath ?? "None"}");
                sb.AppendLine($"File Exists: {File.Exists(primaryPath)}");

                if (File.Exists(primaryPath))
                {
                    try
                    {
                        var fileInfo = new FileInfo(primaryPath);
                        sb.AppendLine($"Last Modified: {fileInfo.LastWriteTime}");
                        sb.AppendLine($"File Size: {fileInfo.Length} bytes");
                    }
                    catch { /* Ignore any errors getting file info */ }
                }

                MessageBox.Show(
                    sb.ToString(),
                    "Configuration Information",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            };

            // Add to menu
            fileToolStripMenuItem.DropDownItems.Add(new ToolStripSeparator());
            fileToolStripMenuItem.DropDownItems.Add(configInfoMenuItem);
        }

        private void SetupTabLayout()
        {
            // Setup tabs and add controls
            tabGeneral.Controls.Add(_generalSettingsControl);
            _generalSettingsControl.Dock = DockStyle.Fill;

            tabDatabase.Controls.Add(_databaseSettingsControl);
            _databaseSettingsControl.Dock = DockStyle.Fill;

            tabInputFields.Controls.Add(_inputFieldsControl);
            _inputFieldsControl.Dock = DockStyle.Fill;

            tabTraining.Controls.Add(_trainingParametersControl);
            _trainingParametersControl.Dock = DockStyle.Fill;
        }

        private async void BtnLaunchTraining_Click(object sender, EventArgs e)
        {
            try
            {
                // First make sure we have a configuration
                if (_currentConfig == null)
                {
                    MessageBox.Show("Please create a configuration first.", "No Configuration",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Update config with latest UI values
                UpdateConfigFromUI();

                // Validate configuration
                if (!_configService.ValidateConfiguration(_currentConfig))
                {
                    MessageBox.Show("Configuration validation failed. Please check all required fields.",
                        "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Save configuration if needed
                if (string.IsNullOrEmpty(_currentFilePath))
                {
                    if (MessageBox.Show("Configuration needs to be saved before training. Save now?",
                        "Save Required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        SaveConfigurationAs();
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    // Save latest changes
                    _configService.SaveConfiguration(_currentConfig, _currentFilePath);
                }

                // Confirm with user
                if (MessageBox.Show("Are you sure you want to start the training process? ",
                    "Confirm Training", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                {
                    return;
                }

                // Switch to the logs tab
                tabControl.SelectedTab = tabLogs;

                // Clear previous logs
                ConsoleUtilities.ClearConsole(txtConsoleOutput);

                // Disable UI during training
                EnableUI(false);
                btnLaunchTraining.BackColor = Color.DarkOrange;
                Application.DoEvents();

                // Run training with progress reporting
                await ConsoleUtilities.RunWithProgressAsync(
                    txtConsoleOutput,
                    () => Task.Run(() => RunTrainingProcess()),
                    "Initializing training process...",
                    "Training process completed!",
                    "Error during training:"
                );

                btnLaunchTraining.Text = "Launch Training";
                btnLaunchTraining.BackColor = Color.Green;
                EnableUI(true);

                // Save log automatically
                string logPath = Path.Combine(
                    Path.GetDirectoryName(_currentFilePath) ?? Environment.CurrentDirectory,
                    $"Training_Log_{DateTime.Now:yyyyMMdd_HHmmss}.txt");


                MessageBox.Show("Training process completed! Check the Training Logs tab for details.",
                    "Training Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                ConsoleUtilities.LogMessage(txtConsoleOutput, $"ERROR: {ex.Message}", LogLevel.Error);
                if (ex.InnerException != null)
                {
                    ConsoleUtilities.LogMessage(txtConsoleOutput, $"Inner exception: {ex.InnerException.Message}", LogLevel.Error);
                }
                ConsoleUtilities.LogMessage(txtConsoleOutput, $"Stack trace: {ex.StackTrace}", LogLevel.Error);

                btnLaunchTraining.Text = "Launch Training";
                btnLaunchTraining.BackColor = Color.Green;
                EnableUI(true);
                MessageBox.Show($"Error during training: {ex.Message}", "Training Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RunTrainingProcess()
        {
            try
            {
                // Save config to temporary file that the ML process can read
                string tempConfigPath = Path.Combine(Path.GetTempPath(), "modelconfig.json");
                var serializableConfig = new Dictionary<string, ModelConfig>
                {
                    { "modelConfig", _currentConfig }
                };

                var options = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                    Converters = { new JsonStringEnumConverter() }
                };

                string jsonConfig = JsonSerializer.Serialize(serializableConfig, options);
                File.WriteAllText(tempConfigPath, jsonConfig);

                var configManager = new ConfigManager();
                var config = configManager.LoadConfiguration(tempConfigPath);

                var sqlHandler = new SqlHandler(config.Database.TableName);
                sqlHandler.Connect(config.Database);

                var enabledFields = config.InputFields
                    .Where(f => f.IsEnabled)
                    .Select(f => f.Name)
                    .ToArray();

                var dataLoader = new DatabaseDataLoader();
                var rawData = dataLoader.LoadDataFromSql(
                    sqlHandler.GetConnectionString(),
                    config.Database.TableName,
                    enabledFields,
                    config.ModelType,
                    config.TargetField,
                    config.Database.WhereClause);

                var mlContext = new Microsoft.ML.MLContext(seed: 42);

                var dataProcessor = new DataProcessor(sqlHandler);
                var processedData = dataProcessor.ProcessData(
                    mlContext,
                    rawData,
                    enabledFields,
                    config).GetAwaiter().GetResult();

                var modelTrainerFactory = new Training.ModelTrainerFactory(mlContext);
                var modelTrainer = modelTrainerFactory.CreateTrainer(config.ModelType);

                modelTrainer.TrainModel(
                    mlContext,
                    processedData.Data,
                    processedData.FeatureNames,
                    config,
                    processedData).GetAwaiter().GetResult();

                // Clean up
                try { File.Delete(tempConfigPath); } catch { }

            }
            catch (Exception ex)
            {
                ConsoleUtilities.LogMessage(txtConsoleOutput, $"Error in training process: {ex.Message}", LogLevel.Error);
                throw;
            }
        }

        private void InitializeMenuItems()
        {
            // File menu
            newToolStripMenuItem.Click += (s, e) => CreateNewConfiguration();
            openToolStripMenuItem.Click += (s, e) => OpenConfiguration();

            // Add reload option
            var reloadMenuItem = new ToolStripMenuItem("Reload Configuration");
            reloadMenuItem.ShortcutKeys = Keys.F5;
            reloadMenuItem.Click += (s, e) => ReloadConfiguration();
            fileToolStripMenuItem.DropDownItems.Insert(2, reloadMenuItem);

            saveToolStripMenuItem.Click += (s, e) => SaveConfiguration();
            saveAsToolStripMenuItem.Click += (s, e) => SaveConfigurationAs();
            exitToolStripMenuItem.Click += (s, e) => Close();
        }

        private void CreateNewConfiguration()
        {
            _currentConfig = new ModelConfig
            {
                Author = Environment.UserName,
                Description = "New Model Configuration",
                ModelType = ModelType.BinaryClassification,
                TargetField = "Label",
                Database = new DatabaseConfig
                {
                    Server = "localhost",
                    Database = "IrisData",
                    TableName = "DataTable",
                    OutputTableName = "",
                    WhereClause = ""
                },
                TrainingParameters = new TrainingParameters
                {
                    Algorithm = "fasttree",
                    TestFraction = 0.2,
                    AlgorithmParameters = new Dictionary<string, object>
                    {
                        { "NumberOfLeaves", 20 }
                    }
                },
                InputFields = new List<InputField>(),
                FeatureEngineering = new FeatureEngineeringConfig
                {
                    Method = FeatureSelectionMethod.None,
                    ExecutionOrder = 2,
                    NumberOfComponents = 3,
                    MaxFeatures = 10,
                    MulticollinearityThreshold = 0.7
                },
                DataBalancing = new DataBalancingConfig
                {
                    Method = DataBalanceMethod.None,
                    ExecutionOrder = 1,
                    KNeighbors = 5,
                    UndersamplingRatio = 0.9f,
                    MinorityToMajorityRatio = 0.1f
                },
                AutoML = new AutoMLConfig
                {
                    Enabled = false,
                    MaxExperimentTimeInSeconds = 30,
                    OptimizingMetric = "Accuracy"
                }
            };

            _currentFilePath = null;
            UpdateFormTitle();
            UpdateUIFromConfig();

            ConsoleUtilities.LogMessage(txtConsoleOutput, "Created new configuration", LogLevel.Info);
        }

        private void OpenConfiguration()
        {
            using (var openFileDialog = new OpenFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                Title = "Open Model Configuration",
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory // Start in app directory
            })
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        _currentConfig = _configService.LoadConfiguration(openFileDialog.FileName);
                        _currentFilePath = openFileDialog.FileName;
                        UpdateFormTitle();
                        UpdateUIFromConfig();

                        // If opened a file that's not in the primary location, save a copy there
                        string primaryPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "modelconfig.json");
                        if (!string.Equals(_currentFilePath, primaryPath, StringComparison.OrdinalIgnoreCase))
                        {
                            try
                            {
                                _configService.SaveConfiguration(_currentConfig, primaryPath);
                                ConsoleUtilities.LogMessage(txtConsoleOutput,
                                    $"Also saved a copy to the primary location: {primaryPath}", LogLevel.Info);
                            }
                            catch (Exception copyEx)
                            {
                                ConsoleUtilities.LogMessage(txtConsoleOutput,
                                    $"Failed to save copy to primary location: {copyEx.Message}", LogLevel.Warning);
                            }
                        }

                        ConsoleUtilities.LogMessage(txtConsoleOutput,
                            $"Loaded configuration from: {_currentFilePath}", LogLevel.Success);
                        MessageBox.Show("Configuration loaded successfully.", "Success",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        ConsoleUtilities.LogMessage(txtConsoleOutput,
                            $"Error loading configuration: {ex.Message}", LogLevel.Error);
                        MessageBox.Show($"Error loading configuration: {ex.Message}", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void SaveConfiguration()
        {
            // Always save to the primary path, which is our "single source of truth"
            string primaryConfigPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "modelconfig.json");

            UpdateConfigFromUI();
            try
            {
                _configService.SaveConfiguration(_currentConfig, primaryConfigPath);
                _currentFilePath = primaryConfigPath; // Ensure the current path is updated
                UpdateFormTitle();

                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    $"Configuration saved to: {primaryConfigPath}", LogLevel.Success);

                MessageBox.Show("Configuration saved successfully.", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    $"Error saving configuration: {ex.Message}", LogLevel.Error);

                MessageBox.Show($"Error saving configuration: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveConfigurationAs()
        {
            using (var saveFileDialog = new SaveFileDialog
            {
                Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                Title = "Save Model Configuration",
                DefaultExt = "json",
                FileName = "modelconfig.json",
                InitialDirectory = AppDomain.CurrentDomain.BaseDirectory // Start in app directory
            })
            {
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    UpdateConfigFromUI();
                    try
                    {
                        _configService.SaveConfiguration(_currentConfig, saveFileDialog.FileName);
                        _currentFilePath = saveFileDialog.FileName;
                        UpdateFormTitle();

                        // Also save a copy to the primary location if different
                        string primaryPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "modelconfig.json");
                        if (!string.Equals(_currentFilePath, primaryPath, StringComparison.OrdinalIgnoreCase))
                        {
                            _configService.SaveConfiguration(_currentConfig, primaryPath);
                            ConsoleUtilities.LogMessage(txtConsoleOutput,
                                $"Also saved a copy to the primary location: {primaryPath}", LogLevel.Info);
                        }

                        ConsoleUtilities.LogMessage(txtConsoleOutput,
                            $"Configuration saved to: {_currentFilePath}", LogLevel.Success);

                        MessageBox.Show("Configuration saved successfully.", "Success",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        ConsoleUtilities.LogMessage(txtConsoleOutput,
                            $"Error saving configuration: {ex.Message}", LogLevel.Error);

                        MessageBox.Show($"Error saving configuration: {ex.Message}", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void ReloadConfiguration()
        {
            try
            {
                // Always reload from the primary path
                string primaryConfigPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "modelconfig.json");

                if (File.Exists(primaryConfigPath))
                {
                    _currentConfig = _configService.LoadConfiguration(primaryConfigPath);
                    _currentFilePath = primaryConfigPath;
                    UpdateFormTitle();
                    UpdateUIFromConfig();

                    ConsoleUtilities.LogMessage(txtConsoleOutput,
                        $"Successfully reloaded configuration from: {primaryConfigPath}", LogLevel.Success);
                }
                else
                {
                    ConsoleUtilities.LogMessage(txtConsoleOutput,
                        $"Configuration file not found at: {primaryConfigPath}", LogLevel.Warning);

                    MessageBox.Show(
                        $"No configuration file found at:\n{primaryConfigPath}",
                        "Configuration Not Found",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                ConsoleUtilities.LogMessage(txtConsoleOutput,
                    $"Error reloading configuration: {ex.Message}", LogLevel.Error);

                MessageBox.Show(
                    $"Error reloading configuration: {ex.Message}",
                    "Reload Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        private void UpdateFormTitle()
        {
            string fileName = Path.GetFileName(_currentFilePath) ?? "Untitled";
            this.Text = $"Iris ML Config - {fileName}";
        }

        private void UpdateUIFromConfig()
        {
            if (_currentConfig == null) return;

            // Update General Settings
            _generalSettingsControl.SetConfiguration(
                _currentConfig.Author,
                _currentConfig.Description,
                _currentConfig.ModelType,
                _currentConfig.TargetField);

            // Update Database Settings
            _databaseSettingsControl.SetConfiguration(_currentConfig.Database);

            // Update Input Fields
            _inputFieldsControl.SetConfiguration(_currentConfig.InputFields);

            // Update Training Parameters
            _trainingParametersControl.SetConfiguration(_currentConfig.TrainingParameters);
        }

        private void UpdateConfigFromUI()
        {
            // Update from General Settings
            var (author, description, modelType, targetField) = _generalSettingsControl.GetValues();
            _currentConfig.Author = author;
            _currentConfig.Description = description;
            _currentConfig.ModelType = modelType;
            _currentConfig.TargetField = targetField;

            // Update from Database Settings
            _currentConfig.Database = _databaseSettingsControl.GetConfiguration();

            // Update from Input Fields
            _currentConfig.InputFields = _inputFieldsControl.GetConfiguration();

            // Update from Training Parameters
            _currentConfig.TrainingParameters = _trainingParametersControl.GetConfiguration();
        }

        private void EnableUI(bool enable)
        {
            tabControl.Enabled = enable;
            menuStrip.Enabled = enable;

            // Keep the logs tab enabled even during training
            if (!enable)
            {
                tabLogs.Enabled = true;
                txtConsoleOutput.Enabled = true;
            }
        }
    }
}